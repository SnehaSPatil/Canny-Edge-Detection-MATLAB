function MF = CannyEdgeDetection(A,sigma, L , H)

% filtering and finding strength and gradient matrix
dst = GuassianFilter(A,sigma);
[Jx,Jy]= gradient(dst);
for i = 1:size(Jx,1)
    for j =1:size(Jy,2)
Es(i,j) = sqrt(Jx(i,j)*Jx(i,j)+Jy(i,j)*Jy(i,j));
Eo(i,j) = atan2d(Jy(i,j),Jx(i,j));
    end 
end
for i = 1:size(Eo,1)
    for j =1:size(Eo,2)
        if(((-22.5 <= Eo(i,j)) && (Eo(i,j) <= 22.5)) || ((157.5 < Eo(i,j))&& (Eo(i,j) <= 180))||((-180 <= Eo(i,j)) && (Eo(i,j) < -157.5)))
            Ed(i,j) = 0;
        elseif(((Eo(i,j) <= -112.5)&& (Eo(i,j)> -157.5)) || ((22.5 < Eo(i,j)) && (Eo(i,j)<= 67.5)))
            Ed(i,j) = 45;
        elseif(((Eo(i,j) > -112.5) && (Eo(i,j)<=-67.5)) || ((67.5 < Eo(i,j))&& (Eo(i,j) <= 112.5)))
            Ed(i,j) = 90;
        elseif(((-67.5 <= Eo(i,j))&&( Eo(i,j)<-22.5)) || ((112.5 < Eo(i,j)) &&(Eo(i,j) <= 157.5)))
            Ed(i,j) = 135;
       end
    end
end
% 
% figure;
% subplot(1,1,1);
% imshow(Es, []);
% title('Es : magnitude');
% 
% figure;
% subplot(1,1,1);
% imshow(Eo, []);
% title('Eo direction');


%Nonax Suppression

Et =zeros(size(Es));
for i = 2:size(Ed,1)-1
    for j = 2:size(Ed,2)-1
        if(Ed(i,j) == 0)
            if((Es(i,j) < Es(i,j-1)) || (Es(i,j) < Es(i,j+1)))
                Et(i,j)= 0;
            else
                Et(i,j)= Es(i,j);
            end
        elseif(Ed(i,j) == 45)
            if((Es(i,j) < Es(i+1,j-1)) || (Es(i,j) < Es(i-1,j+1)))
                Et(i,j)= 0;
            else
                Et(i,j)= Es(i,j);
            end    
        elseif(Ed(i,j) == 90)
            if((Es(i,j) < Es(i-1,j)) || (Es(i,j) < Es(i+1,j)))
                 Et(i,j)= 0;
            else
                Et(i,j)= Es(i,j);
            end
        elseif((Ed(i,j) == 135))
            if((Es(i,j) < Es(i+1,j+1)) || (Es(i,j) < Es(i-1,j-1)))
                 Et(i,j)= 0;
            else
                 Et(i,j)= Es(i,j);
            end
        else
            Et(i,j) = 0;
       end
    end
end
figure;
subplot(1,1,1);
imshow(Et, []);
title('Image after NONMAX SUPPRESSION');

%Thresholding

% Lth = mean(Es(:));
% Hith = Lth+15;
Lth = L;
Hith = H;


val = 70;
B=zeros(size(Es));
Ef = zeros(size(Es));
for i = 1:size(Es,1)
    for j =1:size(Es,2)
         k = i;
         h = j;
        if((Ed(i,j) == 0)&&(Et(i,j) > Hith))
            val= val +1;
           while(Et(k,h) > Lth && k < size(Ed,1)&& B(k,h)==0)
                    Ef(k,h) = Et(k,h);
                    B(k,h) = val;
                    k = k+1;
            end
            k = i;
            h = j;
            while(Et(k,h) > Lth && k >= 1&& B(k,h) == 0)
                    Ef(k,h)= Et(k,h);
                    B(k,h) = val;
                    k = k-1;
             end
        elseif((Ed(i,j) == 45)&&(Et(i,j) > Hith))
           val= val +1;
           while(Et(k,h) > Lth && k < size(Ed,1) && h < size(Ed,2)&& B(k,h)==0)
                Ef(k,h)= Et(k,h);
                B(k,h) = val;
                k = k+1;
                h = h+1;
            end
            k = i;
            h = j;
            while(Et(k,h) > Lth && k >= 1 && h >= 1&& B(k,h) == 0)
                Ef(k,h)= Et(k,h);
                B(k,h) = val;
                k = k-1;
                h = h-1;
            end
        elseif((Ed(i,j) == 90)&&(Et(i,j) > Hith))
            val= val +1;
            while(Et(k,h) > Lth && h <size(Ed,2)&& B(k,h) == 0)
                Ef(k,h)= Et(k,h);
                B(k,h) = val;
                h = h+1;
            end
            h = j;
            while(Et(k,h) > Lth && h >= 1 && B(k,h) == 0)
                Ef(k,h)= Et(k,h);
                B(k,h) = val;
                h = h-1;
            end
           
        elseif((Ed(i,j) == 135)&&(Et(i,j) > Hith))
            val= val +1;
            while(Et(k,h) > Lth && k <size(Ed,1) && h >= 1&& B(k,h) == 0)
                Ef(k,h)= Et(k,h);
                B(k,h) = val;
                k = k+1;
                h = h-1;
            end
            k = i;
            h = j;
            while(Et(k,h) > Lth && k >= 1 && h < size(Ed,2)&& B(k,h) == 0)
                Ef(k,h)= Et(k,h);
                B(k,h) = val;
                k = k-1;
                h = h+1;
            end
        else
            Ef(k,h)= 0;
         end
    end
end
im = imcomplement(Ef);
figure;
subplot(1,1,1);
imshow(Ef, []);
title('Image after HYSTERESIS THRESHOLDING');

%coloring the connected contor

[R,~,v] = find(B);
[M,I] = mode(v);
red = im;
green = im;
blue = im;
  for i = 1:size(Ef,1)
    for j =1:size(Ef,2)
      if(B(i,j)== M)
        red(i,j) = 255;
        green(i,j) = 0;
        blue(i,j) = 0;
        B(i,j)= 0;
       end
     end
  end
[R,~,v] = find(B);
[M,I] = mode(v);
for i = 1:size(Ef,1)
    for j =1:size(Ef,2)
      if(B(i,j)== M)
        red(i,j) = 0;
        green(i,j) = 255;
        blue(i,j) = 0;
        B(i,j)= 0;
       end
     end
 end
[R,~,v] = find(B);
[M,I] = mode(v);
for i = 1:size(Ef,1)
    for j =1:size(Ef,2)
      if(B(i,j)== M)
        red(i,j) = 0;
        green(i,j) = 0;
        blue(i,j) = 255;
        B(i,j)= 0;
       end
     end
end
 
[R,~,v] = find(B);
[M,I] = mode(v);
for i = 1:size(Ef,1)
    for j =1:size(Ef,2)
      if(B(i,j)== M)
        red(i,j) = 255;
        green(i,j) = 255;
        blue(i,j) = 0;
        B(i,j)= 0;
       end
     end
end
 
[R,~,v] = find(B);
[M,I] = mode(v);
for i = 1:size(Ef,1)
    for j =1:size(Ef,2)
      if(B(i,j)== M)
        red(i,j) = 255;
        green(i,j) = 0;
        blue(i,j) = 255;
        B(i,j)= 0;
       end
     end
end

 
[R,~,v] = find(B);
[M,I] = mode(v);
for i = 1:size(Ef,1)
    for j =1:size(Ef,2)
      if(B(i,j)== M)
        red(i,j) = 0;
        green(i,j) = 255;
        blue(i,j) = 255;
        B(i,j)= 0;
       end
     end
 end

figure;
out_image = cat(3, red, green, blue);
imshow(out_image);
title('Image after coloring the maximum number of connected points');

MF = Lth;
